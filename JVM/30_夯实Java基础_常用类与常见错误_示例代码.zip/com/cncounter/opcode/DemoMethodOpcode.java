package com.cncounter.opcode;

/**
 * 演示方法体字节码
 */
public class DemoMethodOpcode {
    public static void main(String[] args) {
    }
}